package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImp;

/**
 * Servlet implementation class UpdatePageServlet
 */
public class UpdatePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	IFilmService filmService=new IFilmServiceImp();
		
		ArrayList<Film> films=filmService.getAllfilms();
	
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+ "</head>"
				+ "<h3> Update Here</h3>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				+ "<table border=1>"
				+ "<tr>"
				+ "<th> Film Id </th>"
				+ "<th> Name </th>"
				+ "<th>	Description	</th>"
				+ "<th>	Release Year	</th>"
				+ "<th>	Original Language	</th>"
				+ "<th>	Rental Duration	</th>"
				+ "<th> Other Lanugages"
				+ "<th> Actors"
				+ "<th>	Length	</th>"
				+ "<th>	Replacement Cost	</th>"
				+ "<th>	Category	</th>"
				+ "<th> Update </th>"
				+ "</tr>");
		
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilm_Id()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getRelease_Year()+"</td>");
				out.println("<td>"+film.getOriginal_Language().getLanguage_Name()+"</td>");
				out.println("<td>"+film.getRental_Duration()+"</td>");
				List<Language>langs=new ArrayList<>();
				langs=film.getLanguages();
				out.println("<td>");
				for(Language lang:langs)
					out.println(lang.getLanguage_Name());
				out.println("</td>");
				Set<Actor> actors =new HashSet<>();
				actors=film.getActors();
				out.println("<td>");
				for(Actor act:actors)
					out.println(act.getActor_First_Name()+" "+act.getActor_last_Name());
				out.println("</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacement_Cost()+"</td>");
				out.println("<td>"+film.getCategory().getCategory_Name()+"</td>");
				out.println("<td><a href='UpdateServlet?filmid="+film.getFilm_Id()+"'>Update</a></td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
	}

}
