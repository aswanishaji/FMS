package com.flp.fms.service;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;

public interface IActorService {
	ArrayList<Actor> displayActors();

}
