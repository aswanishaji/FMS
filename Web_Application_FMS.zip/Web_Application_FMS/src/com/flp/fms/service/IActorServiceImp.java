package com.flp.fms.service;

import java.util.ArrayList;


import com.flp.fms.dao.IActorDAO;
import com.flp.fms.dao.IActorDAOImp;
import com.flp.fms.domain.Actor;

public class IActorServiceImp implements IActorService {

	IActorDAO actordao=new IActorDAOImp();
	@Override
	public ArrayList<Actor> displayActors() {
		// TODO Auto-generated method stub
		return actordao.displayActors();
	}

}
