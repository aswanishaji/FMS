package com.flp.fms.service;

import java.util.ArrayList;

import com.flp.fms.dao.FilmDAO;
import com.flp.fms.dao.FilmDAOImp;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class IFilmServiceImp implements IFilmService {
	FilmDAO filmdao=new FilmDAOImp();
	@Override
	public void addFilm(Film film) {
		
		filmdao.addFilm(film);
	}
	@Override
	public ArrayList<Language> displayLanguages() {
		// TODO Auto-generated method stub
		return filmdao.displayLanguages();
	}
	
	@Override
	public ArrayList<Category> displayCategory() {
		// TODO Auto-generated method stub
		return filmdao.displayCategory();
	}
	@Override
	public ArrayList<Film> getAllfilms() {
		// TODO Auto-generated method stub
		return filmdao.getAllfilms();
	}
	@Override
	public Boolean deleteFilm(int filmid) {
		// TODO Auto-generated method stub
		return filmdao.deleteFilm(filmid);
	}
	@Override
	public ArrayList<Film> searchFilm(Film film) {
		// TODO Auto-generated method stub
		return filmdao.searchFilm(film);
	}
	@Override
	public Boolean updateFilm(Film film) {
		// TODO Auto-generated method stub
		return filmdao.updateFilm(film);
	}
	

}
