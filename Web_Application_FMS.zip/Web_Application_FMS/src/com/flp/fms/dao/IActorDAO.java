package com.flp.fms.dao;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;

public interface IActorDAO {
	ArrayList<Actor> displayActors();

}
