package com.flp.fms.dao;

import java.sql.Connection;
import java.util.ArrayList;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface FilmDAO {

	//Connection getConnection();
	ArrayList<Language> displayLanguages();
	void addFilm(Film film);
	ArrayList<Category> displayCategory();
	ArrayList<Film> getAllfilms();
	Boolean deleteFilm(int filmid);
	ArrayList<Film> searchFilm(Film film);
	Boolean updateFilm(Film film);
	
}