                                          package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao {
	
	HashMap<Integer,Film> film_Repository=new HashMap<>();
//setting languages
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1,"English"));
		languages.add(new Language(2,"Malayalam"));
		languages.add(new Language(3,"Hindi"));
		languages.add(new Language(4,"Tamil"));
		languages.add(new Language(5,"Telungu"));
		languages.add(new Language(6,"Kannada"));
		languages.add(new Language(7,"Marathi"));
		return languages;
	}
//setting categories
	@Override
	public List<Category> getCategory() {
		List<Category> categories=new ArrayList<>();
		categories.add(new Category(1,"Drama"));
		categories.add(new Category(2,"Comdey"));
		categories.add(new Category(3,"Horror"));
		categories.add(new Category(4,"Action"));
		categories.add(new Category(5,"Science Fiction"));
		categories.add(new Category(6,"Animation"));
		return categories;
	}
	//adding film to the repository
	@Override
	public void addFilm(Film film) {
		film_Repository.put(film.getFilm_Id(), film);
		
	}
	//getting all films from repository
	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return film_Repository;
	}
	
	//getting the searched film from repository
	@Override
	public HashMap<Integer, Film> searchfilm() {
		return film_Repository;
	}
	//removing the film from the repository
	@Override
	public void removeFilm(Film film) {
		// TODO Auto-generated method stub
		film_Repository.remove(film.getFilm_Id(), film);
	}
	

}
