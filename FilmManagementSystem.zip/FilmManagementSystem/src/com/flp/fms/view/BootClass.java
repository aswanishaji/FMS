package com.flp.fms.view;

import java.util.Collection;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {

	public static void main(String[] args)
	{
		UserInteraction ui=new UserInteraction();
		IFilmService filmservice=new FilmServiceImpl();
		IActorService actorservice=new ActorServiceImpl();
		String choice1,choice3;
		do{
		menuSelection();
		int choice;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Choice:");
		choice=sc.nextInt();
		switch(choice)
		{//add film
		case 1: 
				Film film=ui.AddFilm(filmservice.getLanguages(),filmservice.getCategory(),actorservice.getActors());
				filmservice.addFilm(film);		
				break;
		//modify film
		case 2: do{
					menuModifySelection();
					int choicem;
					choicem=sc.nextInt();
					Map<Integer,Film> filmList2=filmservice.getAllFilms();
					Collection<Film> lst2=filmList2.values();
					Film f=ui.modifyFilm(lst2,choicem);
					filmservice.removeFilm(f);
					Film newFilm=ui.AddFilm(filmservice.getLanguages(),filmservice.getCategory(),actorservice.getActors());
					filmservice.addFilm(newFilm);
					System.out.println("Do you want to modify again(y/n)");
					choice3=sc.next();
				}while(choice3.charAt(0)=='y'||choice3.charAt(0)=='Y');
				break;
		case 3:
				do{
					menuRemoveSelection();
					int choice2;
					choice2=sc.nextInt();
					Map<Integer,Film> filmList2=filmservice.getAllFilms();
					Collection<Film> lst2=filmList2.values();
					Film f=ui.removeFilm(lst2,choice2);
					filmservice.removeFilm(f);
					System.out.println("Do you want to search again(y/n)");
					choice3=sc.next();
				}while(choice3.charAt(0)=='y'||choice3.charAt(0)=='Y');
					break;
			
		case 4: 	Map<Integer,Film> filmList=filmservice.getAllFilms();
					Collection<Film> lst=filmList.values();
					ui.getAllFilms(lst);
					break;
					
		
		case 5:		do{
					menuSearchSelection();
					int choice2;
					choice2=sc.nextInt();
					Map<Integer,Film> filmList1=filmservice.searchfilm();
					Collection<Film> lst1=filmList1.values();
					ui.SearchFilm(lst1,choice2);
					System.out.println("Do you want to search again(y/n)");
					choice3=sc.next();
					}while(choice3.charAt(0)=='y'||choice3.charAt(0)=='Y');
					break;
		
		case 6:	
				System.exit(0);
				break;
		}System.out.println("Do you want to continue(y/n)");
		choice1=sc.next();
		}while(choice1.charAt(0)=='Y'||choice1.charAt(0)=='y');

	}

	public static void menuSelection()
	{
		System.out.println("\t\t\tFilm Management System");
		System.out.println("MENU");
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film Info");
		System.out.println("3. Remove Film");
		System.out.println("4. View all Film (Film summary)");
		System.out.println("5. Search Film ");
		System.out.println("6. Exit");
	}
	
	public static void menuSearchSelection()
	{
		
		System.out.println("\t\t Search Menu");
		System.out.println("1. Search Film by Film Id");
		System.out.println("2. Search Film by Film Name");
		System.out.println("3. Search Film by Actor");
		System.out.println("4. Search Film by Category");
		System.out.println("5. Search Film by Language");
		System.out.println("6. Search Film by Rating");
		
	}
	public static void menuRemoveSelection()
	{
		
		System.out.println("\t\t Remove Menu");
		System.out.println("1. Remove Film by Rating");
		System.out.println("2. Remove Film by Film Name");
		System.out.println("3. Remove Film by Release Year");
		
		
	}
	public static void menuModifySelection()
	{
		
		System.out.println("\t\t Modify Menu");
		System.out.println("1. Modify Film by Rating");
		System.out.println("2. Modify Film by Film Name");
		System.out.println("3. Modify Film by Release Year");
		
		
	}
}
